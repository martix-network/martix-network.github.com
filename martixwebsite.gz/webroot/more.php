<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Martix Website: more</title>
<style>
  /* Style for the navigation bar */
  .navbar {
    background-color: #FF0000; /* Red color similar to YouTube */
    padding: 10px 20px; /* Adjust padding as needed */
    display: flex;
    justify-content: space-around; /* Centers buttons horizontally */
    align-items: center; /* Centers buttons vertically */
  }
  
  /* Style for the buttons */
  .button {
    display: inline-block;
    padding: 10px 20px;
    background-color: white; /* White color for buttons */
    color: #FF0000; /* Red color for text */
    text-decoration: none;
    border: none;
    border-radius: 3px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease; /* Smooth transition on hover */
    margin-right: 10px; /* Add some spacing between buttons */
  }
  
  /* Style for the buttons when hovered */
  .button:hover {
    background-color: #F5F5F5; /* Light gray background on hover */
  }
</style>
</head>
<body>

<!-- Navigation bar -->
<div class="navbar">
  <a href="http://eu2.minexnodes.com:25567/index.php" class="button">Back Home!</a>
  <a href="http://eu2.minexnodes.com:25567/survival.php" class="button">Survival!</a>
  <a href="http://eu2.minexnodes.com:25567/duels.php" class="button">Duels!</a>
  <a href="http://eu2.minexnodes.com:25567/facsteal.php" class="button">FacSteal!</a>
</div>

</body>
</html>
